# Autonomous Driving Car Simulation

## Objective
Simulate an autonomous driving car using reinforcement learning.

## Technologies
- Python
- TensorFlow/Keras
- OpenAI Gym

## Skills Demonstrated
- Reinforcement learning
- Simulation
- Autonomous systems

## Project Structure
- **data/**: Setup instructions for the environment.
- **notebooks/**: Jupyter notebooks for simulation setup and agent training.
- **scripts/**: Python scripts for environment setup, agent training, and evaluation.
- **models/**: Trained reinforcement learning models.
- **reports/**: Detailed report on the simulation and training.
- **README.md**: Project overview and instructions.
- **requirements.txt**: Required Python packages.
- **LICENSE**: License for the project.

## Instructions
1. Clone the repository.
2. Install the required packages:
   ```sh
   pip install -r requirements.txt
   ```
3. Run the notebooks in the `notebooks/` directory for simulation setup and agent training.
4. Use the scripts in the `scripts/` directory for setting up the environment, training, and evaluating the agent.

## Setup Instructions
- Ensure you have OpenAI Gym installed and properly configured for car simulation.
